/*
	postfix_calculator.cpp

	Implementation of the postfix calculator.

	Author: Dylan Blaine
*/

#include "postfix_calculator.h"
#include <string>
#include <sstream>
#include <iostream>

using namespace std;

bool postfix_calculator::evaluate(string expr) {
    // TODO: Implement as per postfix_calculator.h
    //
    // Read the comments in postfix_calculator.h for this
    // method first!  That is your guide to the required
    // functioning of this method.
    //
    // There are various ways to parse expr.  I suggest
    // you create an istringstream object, constructed on
    // expr:
    // 	istringstream string_in(expr);
    // Then you can get each substring from expr using >>.
    //
    // Check each substring first to see if you have one of
    // the four operators; if not, you can assume the value
    // is a number that you can convert to a double.  (This
    // may not be a good assumption - but we won't test you
    // on robustly handling anything other than numbers and
    // operators.)  You can use the stod() function in the
    // string library to convert strings to doubles.

    istringstream ss(expr); //Create istringstream object.
    string str; //Create string to store each substring.
    double number; //Declare number as  a double.

    //Takes in each substring
    while (ss >> str) {
        //Checks if each substring is an operator. If it is not an operator then it is
        //converted to a double and added to the stack.
        if (str != "+" && str != "-" && str != "*" && str != "/"){
            number = stod(str);
            rpnStack.push(number);
        }

        //If substring is an operator, then the input calculation is carried out.
        else{

            //Returns false if query causes a stack underflow situation.
            if(rpnStack.empty() || rpnStack.size() == 1){
                return false;
            }

            //Gets the two operands from the top of the stack so that calculations
            //can be performed with them.
            _num1 = rpnStack.top();
            rpnStack.pop();
            _num2 = rpnStack.top();
            rpnStack.pop();

            //Performs calculation on the two operands based on the provided operator.
            if (str == "+") {
                _answer = _num2 + _num1;
            } else if (str == "-") {
                _answer = _num2 - _num1;
            } else if (str == "*") {
                _answer = _num2 * _num1;
            } else {
                _answer = _num2 / _num1;
            }
            //Adds the resulting answer back to the stack.
            rpnStack.push(_answer);
        }

    }
    return true;
}

// TODO: Implement the remaining functions specified
// in postfix_calculator.h.
//
// You should start by creating "stubs" for each of
// the methods - these are methods that do nothing
// except return a value if needed.  For example, the
// evaluate() method above does nothing but return true.
//
// Once you've got stubs for everything, then you should
// be able to compile and test the user interface.  Then
// start implementing functions, *testing constantly*!


void postfix_calculator::clear(){
    //Clears stack until it is empty.
    while(!rpnStack.empty()){
        rpnStack.pop();
    }
    //Clears copy of the stack until it is empty.
    while (!copy.empty()){
        copy.pop();
    }
}

//Returns the number at the top of the stack, if the stack is empty, then function returns 0.0
double postfix_calculator::top(){
    if(rpnStack.empty()){
        return 0.0;
    }
    else{
        return rpnStack.top();
    }
}

//Returns the copy of the stack to display the stacks elements.
std::string postfix_calculator::to_string(){
   copy = rpnStack;
   string stackCopy;
    for (int i = 0; i < rpnStack.size(); ++i) {
        stackCopy = stackCopy + '\n' + ::to_string(copy.top());
        copy.pop();
    }
    return stackCopy;
}

//Default constructor
postfix_calculator::postfix_calculator(){
    _answer = 0;
}

